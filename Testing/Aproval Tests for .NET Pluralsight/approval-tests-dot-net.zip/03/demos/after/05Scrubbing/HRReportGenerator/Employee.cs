﻿using System;

namespace HRReportGenerator
{
    public class Employee
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int PayGrade { get; set; }
        public DateTime DateOfBirth { get; set; }
    }
}
