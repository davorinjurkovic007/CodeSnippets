﻿using ApprovalTests;
using ApprovalTests.Reporters;
using Hangman;
using System.Text;
using Xunit;

namespace Tests
{
    public class GameEngineShould
    {
        [Fact]
        [UseReporter(typeof(DiffReporter))]
        public void UpdateGameState()
        {
            var sut = new GameEngine("Pluralsight");

            sut.Guess('x');
            sut.Guess('p');
            sut.Guess('l');

            Approvals.Verify(sut);
        }

        [Fact]
        [UseReporter(typeof(DiffReporter))]
        public void UpdateGameState_Intermediate_Steps()
        {
            var sb = new StringBuilder();
            var sut = new GameEngine("Pluralsight");

            sb.AppendLine(sut.ToString());

            sut.Guess('x');
            sb.AppendLine(sut.ToString());

            sut.Guess('p');
            sb.AppendLine(sut.ToString());

            sut.Guess('l');
            sb.Append(sut.ToString());

            Approvals.Verify(sb);
        }
    }
}
