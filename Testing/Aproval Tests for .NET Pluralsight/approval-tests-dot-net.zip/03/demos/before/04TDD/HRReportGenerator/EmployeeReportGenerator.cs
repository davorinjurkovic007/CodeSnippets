﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Text;

namespace HRReportGenerator
{
    public class EmployeeReportGenerator
    {
 

    }
}
