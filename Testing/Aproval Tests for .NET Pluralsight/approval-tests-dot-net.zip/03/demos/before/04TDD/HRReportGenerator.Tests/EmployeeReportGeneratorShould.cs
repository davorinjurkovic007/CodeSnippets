using System;
using Xunit;
using ApprovalTests;

namespace HRReportGenerator.Tests
{
    public class EmployeeReportGeneratorShould
    {
        [Fact]
        public void GenerateCorrectReportWhenMultipleEmployees()
        {
            
        }
    }
}
