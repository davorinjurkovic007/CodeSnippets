﻿using Hangman;
using Xunit;

namespace Tests
{
    public class GameEngineShould
    {
        [Fact]
        public void UpdateGameState()
        {

        }
    }
}
