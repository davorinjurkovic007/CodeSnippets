﻿using ApprovalTests.Reporters;
using ApprovalTests.Wpf;
using System;
using Xunit;

namespace HangmanGameWPF.Tests
{
    public class GameUIShould
    {
        [WpfFact]
        [UseReporter(typeof(DiffReporter), typeof(ClipboardReporter))]
        public void RenderInitialViewState()
        {
            // Create model
            var model = new GameEngine("Pluralsight");

            // No other state set in model as we want initial view state

            // Create view and set its model
            var sut = new MainWindow();
            sut.DataContext = model;

            // Verify view is displaying model correctly
            WpfApprovals.Verify(sut);
        }

        [WpfFact]
        [UseReporter(typeof(DiffReporter), typeof(ClipboardReporter))]
        public void PlayingState()
        {
            // Create model
            var model = new GameEngine("Pluralsight");

            // set model to state we want to test
            model.Guess('o');
            model.Guess('p');
            model.Guess('l');

            // Create view and set its model
            var sut = new MainWindow();
            sut.DataContext = model;

            // Verify view is displaying model correctly
            WpfApprovals.Verify(sut);
        }
    }
}
