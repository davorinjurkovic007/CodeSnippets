using ApprovalTests;
using ApprovalTests.Reporters;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using Xunit;

namespace WebApplication1.Tests
{
    public class HomePageShould
    {
        [Fact]
        [UseReporter(typeof(DiffReporter), typeof(ClipboardReporter))]
        public void RenderWithoutError()
        {
            using (IWebDriver driver = new ChromeDriver())
            {
                // Make sure consistent known browser size
                driver.Manage().Window.Size = new System.Drawing.Size(1000, 800);

                // Make sure this matches WebApplication1 App Url setting in the 
                // properties Debug tab and that the web site is running 
                // before executing the test (e.g. Debug -> Start Without Debugging)
                const string homeUrl = "http://localhost:6858";

                driver.Navigate().GoToUrl(homeUrl);

                ITakesScreenshot screenshotDriver = (ITakesScreenshot)driver;
                Screenshot screen = screenshotDriver.GetScreenshot();

                Approvals.VerifyBinaryFile(screen.AsByteArray, ".png");
            }
        }
    }
}
