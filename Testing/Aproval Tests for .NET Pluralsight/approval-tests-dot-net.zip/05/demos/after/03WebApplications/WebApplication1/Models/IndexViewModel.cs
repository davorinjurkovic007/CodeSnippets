﻿namespace WebApplication1.Models
{
    public class IndexViewModel
    {
        public string Greeting { get; set; }
        public string LongGreeting { get; set; }
    }
}
