﻿using ApprovalTests.Reporters;
using ApprovalTests.WinForms;
using Xunit;

namespace HangmanGameWinForms.Tests
{
    public class GameUIShould
    {
        [Fact]
        [UseReporter(typeof(DiffReporter), typeof(ClipboardReporter))]
        public void PlayingState()
        {
            var model = new GameEngine("Pluralsight");

            model.Guess('o');
            model.Guess('p');
            model.Guess('l');

            var sut = new Form1();
            sut.SetModel(model);

            WinFormsApprovals.Verify(sut);
        }
    }
}
