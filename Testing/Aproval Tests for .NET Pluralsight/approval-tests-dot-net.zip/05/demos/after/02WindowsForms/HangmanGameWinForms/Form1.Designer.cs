﻿namespace HangmanGameWinForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRevealedWord = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblGuessedLetters = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblLivesLeft = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblRevealedWord
            // 
            this.lblRevealedWord.AutoSize = true;
            this.lblRevealedWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRevealedWord.ForeColor = System.Drawing.Color.Magenta;
            this.lblRevealedWord.Location = new System.Drawing.Point(20, 23);
            this.lblRevealedWord.Name = "lblRevealedWord";
            this.lblRevealedWord.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblRevealedWord.Size = new System.Drawing.Size(99, 76);
            this.lblRevealedWord.TabIndex = 0;
            this.lblRevealedWord.Text = "---";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label1.Location = new System.Drawing.Point(20, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(367, 55);
            this.label1.TabIndex = 1;
            this.label1.Text = "Letters guessed";
            // 
            // lblGuessedLetters
            // 
            this.lblGuessedLetters.AutoSize = true;
            this.lblGuessedLetters.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuessedLetters.ForeColor = System.Drawing.Color.Magenta;
            this.lblGuessedLetters.Location = new System.Drawing.Point(23, 149);
            this.lblGuessedLetters.Name = "lblGuessedLetters";
            this.lblGuessedLetters.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblGuessedLetters.Size = new System.Drawing.Size(96, 55);
            this.lblGuessedLetters.TabIndex = 2;
            this.lblGuessedLetters.Text = "xyz";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(20, 204);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(212, 55);
            this.label2.TabIndex = 3;
            this.label2.Text = "Lives left";
            // 
            // lblLivesLeft
            // 
            this.lblLivesLeft.AutoSize = true;
            this.lblLivesLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLivesLeft.ForeColor = System.Drawing.Color.Magenta;
            this.lblLivesLeft.Location = new System.Drawing.Point(224, 204);
            this.lblLivesLeft.Name = "lblLivesLeft";
            this.lblLivesLeft.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblLivesLeft.Size = new System.Drawing.Size(78, 55);
            this.lblLivesLeft.TabIndex = 4;
            this.lblLivesLeft.Text = "99";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(445, 372);
            this.Controls.Add(this.lblLivesLeft);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblGuessedLetters);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblRevealedWord);
            this.Name = "Form1";
            this.Text = "Form1";            
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRevealedWord;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblGuessedLetters;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblLivesLeft;
    }
}

