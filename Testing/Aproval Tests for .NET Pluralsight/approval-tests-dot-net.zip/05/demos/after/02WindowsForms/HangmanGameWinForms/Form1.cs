﻿using System.Globalization;
using System.Windows.Forms;

namespace HangmanGameWinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            SetModel(new GameEngine("Pluralsight"));
        }

        public void SetModel(GameEngine model)
        {
            lblRevealedWord.Text = model.RevealedWord;
            lblGuessedLetters.Text = model.GuessedLetters;
            lblLivesLeft.Text = model.GuessesRemaining.ToString(CultureInfo.InvariantCulture);
        }
    }
}
