﻿using ApprovalTests.Reporters;
using ApprovalTests.Wpf;
using System;
using Xunit;

namespace HangmanGameWPF.Tests
{
    public class GameUIShould
    {
        [WpfFact]
        [UseReporter(typeof(DiffReporter), typeof(ClipboardReporter))]
        public void RenderStickmanDrawing()
        {
            // Create model
            var model = new GameEngine("Pluralsight");

            model.Guess('o');
            model.Guess('p');
            model.Guess('l');
            model.Guess('z');
            model.Guess('y');
            model.Guess('x');
            model.Guess('v');
            model.Guess('c');

            // Create view and set its model
            var sut = new MainWindow();
            sut.DataContext = model;

            // Verify view is displaying model correctly
            WpfApprovals.Verify(sut);
        }
    }
}
