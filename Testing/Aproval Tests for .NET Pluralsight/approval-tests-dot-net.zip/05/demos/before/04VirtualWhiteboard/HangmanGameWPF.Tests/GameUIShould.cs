﻿using ApprovalTests.Reporters;
using ApprovalTests.Wpf;
using System;
using Xunit;

namespace HangmanGameWPF.Tests
{
    public class GameUIShould
    {
        [WpfFact]
        [UseReporter(typeof(DiffReporter), typeof(ClipboardReporter))]
        public void RenderStickmanDrawing()
        {
            // Create model
            var model = new GameEngine("Pluralsight");
            

            // Create view and set its model
            var sut = new MainWindow();
            sut.DataContext = model;

            // Verify view is displaying model correctly
            WpfApprovals.Verify(sut);
        }
    }
}
