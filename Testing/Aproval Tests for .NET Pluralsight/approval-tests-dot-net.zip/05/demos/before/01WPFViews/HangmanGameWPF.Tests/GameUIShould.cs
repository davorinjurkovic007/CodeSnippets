﻿using ApprovalTests.Reporters;
using System;
using Xunit;

namespace HangmanGameWPF.Tests
{
    public class GameUIShould
    {

    }
}
