using ApprovalTests;
using ApprovalTests.Reporters;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using Xunit;

namespace WebApplication1.Tests
{
    public class HomePageShould
    {

    }
}
