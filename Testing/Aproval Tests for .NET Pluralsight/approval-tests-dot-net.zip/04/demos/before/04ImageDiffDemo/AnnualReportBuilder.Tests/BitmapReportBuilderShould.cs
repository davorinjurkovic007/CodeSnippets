﻿using ApprovalTests.Reporters;
using AnnualReportBuilder;
using Xunit;
using ApprovalTests;

namespace Tests
{
    public class BitmapReportBuilderShould
    {

    }
}
