﻿using ApprovalTests.Reporters;
using Xunit;
using ApprovalTests;

namespace ReportGenerator.Tests
{
    public class HtmlReportBuilderShould
    {
       
    }
}
