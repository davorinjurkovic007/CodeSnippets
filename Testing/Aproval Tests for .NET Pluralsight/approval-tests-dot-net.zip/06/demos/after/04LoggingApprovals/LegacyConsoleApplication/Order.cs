﻿namespace LegacyConsoleApplication
{
    internal class Order
    {
        public int Id { get; set; }
        public decimal OrderTotal { get; set; }
    }
}
