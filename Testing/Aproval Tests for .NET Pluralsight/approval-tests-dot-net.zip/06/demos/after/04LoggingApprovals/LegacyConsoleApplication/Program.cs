﻿using ApprovalUtilities.SimpleLogger;
using System;

namespace LegacyConsoleApplication
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            Logger.Event("Program started");
            Console.WriteLine("Processing, please wait...");

            var operation = args[0];
            Logger.Variable("operation", operation);
         

            if (operation == "SHIPORDERS")
            {
                Logger.Message("Shipping orders");
                var orders = DatabaseConnection.GetUnfulfilledOrderNums();

                foreach (Order order in orders)
                {
                    if (order.OrderTotal > 200)
                    {
                        DatabaseConnection.InsertPriorityOrder(order);
                    }
                    else
                    {
                        DatabaseConnection.InsertNormalOrder(order);
                    }
                }
            }
            else if (operation == "DELETEOLDORDERS")
            {
                Logger.Message("Deleting old orders");
                DatabaseConnection.DeleteOldOrders();
            }


            Console.WriteLine("Processing complete.");
            Logger.Event("Program ended");
        }
    }
}
