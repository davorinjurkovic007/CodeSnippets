﻿using ApprovalTests;
using ApprovalTests.Reporters;
using ApprovalUtilities.SimpleLogger;
using Xunit;

namespace LegacyConsoleApplication.Tests
{
    public class LegacyConsoleApplicationShould
    {
        [Fact]
        [UseReporter(typeof (DiffReporter),typeof(ClipboardReporter))]
        public void ShipOrders()
        {
            var log = Logger.LogToStringBuilder();

            Program.Main(new[] { "SHIPORDERS" });

            string logResult = log.ToString();

            Approvals.Verify(logResult);
        }
    }
}
