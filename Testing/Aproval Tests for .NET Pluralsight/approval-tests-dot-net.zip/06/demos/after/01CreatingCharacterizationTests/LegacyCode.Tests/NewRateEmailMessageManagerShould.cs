﻿using ApprovalTests;
using ApprovalTests.Reporters;
using Xunit;

namespace LegacyCode.Tests
{
    public class NewRateEmailMessageManagerShould
    {
        [Fact]
        [UseReporter(typeof(DiffReporter))]
        public void GenerateEmailMessageForCredit()
        {
            var sut = new NewRateEmailMessageManager();

            string message = sut.CreateMessageBody("Sarah", AccountType.Credit,
                "1111", true, 5.2M);

            Approvals.Verify(message);
        }

        [Fact]
        [UseReporter(typeof(DiffReporter))]
        public void GenerateEmailMessageForCheque()
        {
            var sut = new NewRateEmailMessageManager();

            var message = sut.CreateMessageBody("Amrit", AccountType.Cheque,
                 "2222", false, 0.00001M);

            Approvals.Verify(message);
        }
    }
}
