﻿using ApprovalTests;
using ApprovalTests.Combinations;
using ApprovalTests.Reporters;
using Xunit;

namespace LegacyCode.Tests
{
    public class NewRateEmailMessageManagerShould
    {
        [Fact]
        [UseReporter(typeof(DiffReporter))]
        public void GenerateEmailMessageCombinations()
        {
            var sut = new NewRateEmailMessageManager();

            var names = new[] { "Amrit", "Sarah" };
            var accountTypes = new[]
                               {
                                   AccountType.Cheque,
                                   AccountType.Savings,
                                   AccountType.Credit
                               };
            var accNums = new[] { "1234" };
            var showAccounts = new[] { true, false };
            var newRates = new[] { 10.5M, 40.22M };

            //string message = sut.CreateMessageBody("Sarah", AccountType.Credit,
            //    "1111", true, 5.2M);

            CombinationApprovals.VerifyAllCombinations(sut.CreateMessageBody,
                names, accountTypes, accNums, showAccounts, newRates);
        }
    }
}
