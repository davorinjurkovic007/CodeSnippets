﻿namespace LegacyCode
{
    public enum AccountType
    {
        Cheque,
        Savings,
        Credit
    }
}