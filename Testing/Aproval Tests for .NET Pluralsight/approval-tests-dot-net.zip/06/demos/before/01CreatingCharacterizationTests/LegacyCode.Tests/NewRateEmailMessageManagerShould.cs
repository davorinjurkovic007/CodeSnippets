﻿using ApprovalTests.Reporters;
using Xunit;

namespace LegacyCode.Tests
{
    public class NewRateEmailMessageManagerShould
    {
        [Fact]
        [UseReporter(typeof(DiffReporter))]
        public void GenerateEmailMessageForCredit()
        {

        }
    }
}
