﻿using ApprovalTests;
using ApprovalTests.Reporters;
using Xunit;

namespace LegacyConsoleApplication.Tests
{
    public class LegacyConsoleApplicationShould
    {
        [Fact]
        [UseReporter(typeof (DiffReporter),typeof(ClipboardReporter))]
        public void ShipOrders()
        {

        }
    }
}
