﻿using System;

namespace LegacyConsoleApplication
{
    public static class Program
    {
        public static void Main(string[] args)
        {

            Console.WriteLine("Processing, please wait...");

            var operation = args[0];

         

            if (operation == "SHIPORDERS")
            {
         
                var orders = DatabaseConnection.GetUnfulfilledOrderNums();

                foreach (Order order in orders)
                {
                    if (order.OrderTotal > 200)
                    {
                        DatabaseConnection.InsertPriorityOrder(order);
                    }
                    else
                    {
                        DatabaseConnection.InsertNormalOrder(order);
                    }
                }
            }
            else if (operation == "DELETEOLDORDERS")
            {
      
                DatabaseConnection.DeleteOldOrders();
            }


            Console.WriteLine("Processing complete.");
        }
    }
}
