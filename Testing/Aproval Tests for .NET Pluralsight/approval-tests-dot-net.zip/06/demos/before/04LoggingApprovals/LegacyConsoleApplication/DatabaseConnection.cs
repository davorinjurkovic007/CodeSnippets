﻿using System.Collections.Generic;

namespace LegacyConsoleApplication
{
    internal static class DatabaseConnection
    {
        public static List<Order> GetUnfulfilledOrderNums()
        {
            var sql = "SELECT orderId, orderValue FROM Orders WHERE Shipped = 0";         

            // simulate database for demo purposes
            return new List<Order>
                   {
                       new Order {Id = 1, OrderTotal = 400.22M},
                       new Order {Id = 4, OrderTotal = 100.00M},
                       new Order {Id = 34, OrderTotal = 99}
                   };

        }

        public static void InsertPriorityOrder(Order order)
        {

            var sql = $"INSERT INTO PriOrder VALUES ({order.Id})";

            // simulate database for demo purposes
        }

        public static void InsertNormalOrder(Order order)
        {

            var sql = $"INSERT INTO NormOrder VALUES ({order.Id})";

            // simulate database for demo purposes
        }

        public static void DeleteOldOrders()
        {
            // etc.
        }
    }
}
