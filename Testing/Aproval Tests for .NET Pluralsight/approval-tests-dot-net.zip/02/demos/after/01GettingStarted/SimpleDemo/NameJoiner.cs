﻿namespace SimpleDemo
{
    public class NameJoiner
    {
        public string Join(string firstName, string surname)
        {
            return firstName + " " + surname;
        }
    }
}
