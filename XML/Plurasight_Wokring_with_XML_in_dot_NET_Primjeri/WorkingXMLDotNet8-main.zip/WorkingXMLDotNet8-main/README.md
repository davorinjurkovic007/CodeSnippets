# WorkingXMLDotNet8
Starting Samples for my LINQ Fundamentals in C# on Pluralsight
