﻿using XMLSamples;
 
// Create instance of view model
CachingViewModel vm = new();

// Call Sample Method
vm.GetData();

// Stop console to view results
Console.ReadKey();