﻿using System.Text;
using System.Text.Json;

var optionsWriter = new JsonWriterOptions
{
    Indented = true
};

// 1. Write a JSON object directly using Utf8JsonWriter to a MemoryStream
using var stream = new MemoryStream();
using var writer = new Utf8JsonWriter(stream, optionsWriter);

writer.WriteStartObject();

// Property
writer.WritePropertyName("company");
writer.WriteStringValue("Carved Rock");

// Date
writer.WriteString("date", DateTimeOffset.UtcNow);
writer.WriteNumber("temperaturecelsius", 7);
writer.WriteNumber("feelslike", 3.14);
writer.WriteString("description", "overcast clouds");
writer.WriteNumber("pressure", 1003);
writer.WriteNumber("humidity", 79);

// Object
writer.WriteStartObject("coord");
writer.WriteNumber("lon", 48.75);
writer.WriteNumber("lon", 8.24);
writer.WriteEndObject();

writer.WriteStartObject("wind");
writer.WriteNumber("speed", 11.32);
writer.WriteNumber("deg", 200);
writer.WriteNumber("gust", 17.49);
writer.WriteEndObject();

writer.WriteStartArray("keywords");
writer.WriteStringValue("Chill");
writer.WriteStringValue("Windy");
writer.WriteEndArray();

writer.WriteString("country", "DE");
writer.WriteString("city", "Baden-Baden");

// Nulls
writer.WriteNull("tsunami");

writer.WriteStartArray("tsunamiLocations");
writer.WriteNullValue();
writer.WriteEndArray();

// Raw content""last7days"": 
 string jsonLastSeven = @"[
    {
      ""temperature"": 5, 
      ""humidity"": 79
    },
    {
      ""temperature"": 3, 
      ""humidity"": 65
    },
    {
      ""temperature"": 7, 
      ""humidity"": 70
    },
    {
      ""temperature"": 8, 
      ""humidity"": 77
    },
    {
      ""temperature"": 4, 
      ""humidity"": 60
    },
    {
      ""temperature"": 5, 
      ""humidity"": 85
    },
    {
      ""temperature"": 9, 
      ""humidity"": 74
    }
  ]";
writer.WritePropertyName("last7days");
writer.WriteRawValue(jsonLastSeven);

writer.WriteEndObject();
writer.Flush();

string json = Encoding.UTF8.GetString(stream.ToArray());
Console.WriteLine(json);
Console.Clear();

// Note: To write UTF8 use custom encoding as explained in "Customizing Character Encoding" clip in the previous module


// 2. Can also use JsonDocument to write a JSON text
string inputFileName = "wind.json";
string outputFileName = "output.json";

string jsonString = File.ReadAllText(inputFileName);

var documentOptions = new JsonDocumentOptions
{
    CommentHandling = JsonCommentHandling.Skip
};

using FileStream fs = File.Create(outputFileName);
using var writerWind = new Utf8JsonWriter(fs);
using JsonDocument document = JsonDocument.Parse(jsonString, documentOptions);

JsonElement root = document.RootElement;

if (root.ValueKind == JsonValueKind.Object)
{
    writerWind.WriteStartObject();
}
else
{
    return;
}

foreach (JsonProperty property in root.EnumerateObject())
{
    property.WriteTo(writerWind);
}

writerWind.WriteEndObject();

writerWind.Flush();
Console.Clear();