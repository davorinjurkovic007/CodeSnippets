﻿using System.Text;
using System.Text.Json;

// The BOM (byte order mark) which is used to determine if it is UTF8
byte[] Utf8Bom = new byte[] { 0xEF, 0xBB, 0xBF };

// A byte[] with "feelslike" that I am going to use for comparison
byte[] s_nameUtf8 = Encoding.UTF8.GetBytes("feelslike");


// ReadAllBytes 
string fileName = "daily_weather.json";
ReadOnlySpan<byte> jsonReadOnlySpan = File.ReadAllBytes(fileName);

// Read past the UTF-8 BOM bytes if a BOM exists
if (jsonReadOnlySpan.StartsWith(Utf8Bom))
{
    jsonReadOnlySpan = jsonReadOnlySpan.Slice(Utf8Bom.Length);
}

// Or read as UTF-16 and transcode to UTF-8 to convert to a ReadOnlySpan<byte>
//string fileName = "daily_weather_utf8.json";
//string jsonString = File.ReadAllText(fileName);
//ReadOnlySpan<byte> jsonReadOnlySpan = Encoding.UTF8.GetBytes(jsonString);

int count = 0;
int total = 0;
string text;

var reader = new Utf8JsonReader(jsonReadOnlySpan);

while (reader.Read())
{
    JsonTokenType tokenType = reader.TokenType;
    Console.WriteLine(tokenType.ToString());

    switch (tokenType)
    {
        case JsonTokenType.StartObject:
            total++;
            break;
        case JsonTokenType.PropertyName:
            text = reader.GetString();
            Console.WriteLine(" " + text);
            if (reader.ValueTextEquals(s_nameUtf8))
            {
                // Assume valid JSON, known schema
                reader.Read();
                int feelsL = reader.GetInt32();
                Console.WriteLine(" " + feelsL);
                if (feelsL < 0)
                {
                    count++;
                }
            }
            break;
        case JsonTokenType.String:
        {
            text = reader.GetString();
            Console.WriteLine(" " + text);
            break;
        }
        case JsonTokenType.Number:
        {
            int intValue = reader.GetInt32();
            Console.WriteLine(" " + intValue);
            break;
        }
    }
}

Console.WriteLine($"{count} out of {total} temperatures are below 0");
