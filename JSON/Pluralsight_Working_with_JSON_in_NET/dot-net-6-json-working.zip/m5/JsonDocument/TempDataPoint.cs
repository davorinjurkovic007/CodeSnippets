public class TempDataPoint
{
    public int temperature { get;set; }
    public int humidity{ get;set; }
}