﻿using System.Text.Json;

// Create a new WeatherForecast object
var weatherForecast = new WeatherForecast
{
    Date = DateTime.Parse("2021-12-01"),
    TemperatureCelsius = 17,
    Summary = "Overcast Clouds",
    Pressure = 1018,
    Humidity = 85,
    Coordinates = new Coordinates()
    {
        Lon = -83.9167,
        Lat = 9.8667
    },
    Wind = new Wind()
    {
        Speed = 1.79,
        Degree = 157,
        Gust = 3.58
    },
    SummaryWords = new[] { "Cool", "Windy", "Humid" }
};

// Serialize weatherForecast
string jsonString = JsonSerializer.Serialize(weatherForecast);

// Print the serialized JSON string
Console.WriteLine(jsonString);
Console.Clear();