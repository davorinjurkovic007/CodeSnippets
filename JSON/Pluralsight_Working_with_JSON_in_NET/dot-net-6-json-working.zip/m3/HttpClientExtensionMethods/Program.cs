﻿using System.Net.Http.Json;

// 1. GET
using HttpClient client = new()
{
    // jsonplaceholder.typicode.com is a free fake API for testing and prototyping 
    BaseAddress = new Uri("https://jsonplaceholder.typicode.com")
};

// Get user 1
// https://jsonplaceholder.typicode.com/users/1
User? user = await client.GetFromJsonAsync<User>("users/1");

if (user != null)
{
    Console.WriteLine($"Id: {user.Id}");
    Console.WriteLine($"Name: {user.Name}");
    Console.WriteLine($"Username: {user.Username}");
    Console.WriteLine($"Email: {user.Email}");
}

Console.Clear();

// 2. POST
User newUser = new User()
{
    Id = 42,
    Name = "Xavier Morera",
    Email = "xavier@youcanprobablyfindthiseasily.com",
    Username = "xmorera"
};

// Post a new user
HttpResponseMessage response = await client.PostAsJsonAsync("users", newUser);

// Print the response code
Console.WriteLine($"{(response.IsSuccessStatusCode ? "Success" : "Error")} - {response.StatusCode}");
Console.Clear();