﻿using System.Text.Json;

// String variable that contains the JSON text
string jsonString = @"{
   ""Date"":""2021-12-01T00:00:00-06:00"",
   ""TemperatureCelsius"":17,
   ""Summary"":""Overcast Clouds"",
   ""Pressure"":1018,
   ""Humidity"":85,
   ""Coordinates"":{
      ""Lon"":-83.9167,
      ""Lat"":9.8667
   },
   ""Wind"":{
      ""Speed"":1.79,
      ""Degree"":157,
      ""Gust"":3.58
   },
   ""SummaryWords"":[
      ""Cool"",
      ""Windy"",
      ""Humid""
   ]
}";

// .NET object deserialized from the JSON string
WeatherForecast? weatherForecast = JsonSerializer.Deserialize<WeatherForecast>(jsonString);

// Check if object was deserialized successfully
if (weatherForecast != null)
{
    //Print a few deserialized properties
    Console.WriteLine($"Date: {weatherForecast.Date}");
    Console.WriteLine($"TemperatureCelsius: {weatherForecast.TemperatureCelsius}");
    Console.WriteLine($"Summary: {weatherForecast.Summary}");
}