﻿using System.Text.Json;

// JSON filename 
string fileName = "WeatherForecast.json";

// Read JSON from a local File
using FileStream openStream = File.OpenRead(fileName);

// Deserialize the JSON text to a WeatherForecast object asynchronously
WeatherForecast? weatherForecast = await JsonSerializer.DeserializeAsync<WeatherForecast>(openStream);

// Check if object was deserialized successfully
if (weatherForecast != null)
{
    //Print a few deserialized properties
    Console.WriteLine($"Date: {weatherForecast.Date}");
    Console.WriteLine($"TemperatureCelsius: {weatherForecast.TemperatureCelsius}");
    Console.WriteLine($"Summary: {weatherForecast.Summary}");
}