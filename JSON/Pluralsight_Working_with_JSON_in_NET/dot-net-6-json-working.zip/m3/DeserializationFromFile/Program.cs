﻿using System.Text.Json;

// JSON filename
string fileName = "WeatherForecast.json";

// Extract the JSON text from the file
string jsonString = File.ReadAllText(fileName);

// Deserialize the JSON text to a WeatherForecast object
WeatherForecast? weatherForecast = JsonSerializer.Deserialize<WeatherForecast>(jsonString);

// if weather object was deserialized successfully (we don't want unexpected errors)
if (weatherForecast != null)
{
    // Print some deserialized properties
    Console.WriteLine($"Date: {weatherForecast.Date}");
    Console.WriteLine($"TemperatureCelsius: {weatherForecast.TemperatureCelsius}");
    Console.WriteLine($"Summary: {weatherForecast.Summary}");

}