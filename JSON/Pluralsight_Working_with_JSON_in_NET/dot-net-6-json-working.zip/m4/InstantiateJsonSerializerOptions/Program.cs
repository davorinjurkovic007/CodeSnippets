﻿using System.Text.Json;

var Coordinates = new Coordinates()
{
    Lon = -83.9167,
    Lat = 9.8667
};

var Wind = new Wind()
{
    Speed = 1.79,
    Degree = 157,
    Gust = 3.58
};

// With no options
Console.WriteLine(JsonSerializer.Serialize(Coordinates));
Console.Clear();

// 1. Instantiate a new JsonSerializerOptions class
// Instantiate a new JsonSerializerOptions class and pass as parameter WriteIndented for pretty printing
var options = new JsonSerializerOptions { WriteIndented = true };

// Options passed as the second parameter
string coordinatesJson = JsonSerializer.Serialize(Coordinates, options);

// Print the serialized JSON string
Console.WriteLine(coordinatesJson);
Console.Clear();

// 2. Reuse the JsonSerializerOptions class
// The JsonSerializerOptions can be reused
string windJson = JsonSerializer.Serialize(Wind, options);

// Print the serialized JSON string
Console.WriteLine(windJson);
Console.Clear();

// 3. Copy an existing JsonSerializerOptions object
// Create a new JsonSerializerOptions instance from an existing one 
var optionsCopy = new JsonSerializerOptions(options);

// Call serialize and pass the new instance
string windJsonTwo = JsonSerializer.Serialize(Wind, optionsCopy);

// Print the serialized JSON string
Console.WriteLine(windJsonTwo);
Console.Clear();

// 4. Use the constructor that creates a new instance with the default options that ASP.NET Core uses for web apps
//      PropertyNameCaseInsensitive = true
//      JsonNamingPolicy = CamelCase
//      NumberHandling = AllowReadingFromString
var optionsWeb = new JsonSerializerOptions(JsonSerializerDefaults.Web);

// Call serialize with web defaults
string webDefaultsJson = JsonSerializer.Serialize(Wind, optionsWeb);

// Print the serialized JSON string
Console.WriteLine(webDefaultsJson);
Console.Clear();