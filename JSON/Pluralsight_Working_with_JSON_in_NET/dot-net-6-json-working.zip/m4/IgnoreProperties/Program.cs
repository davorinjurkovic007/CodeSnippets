﻿using System.Text.Json;
using System.Text.Json.Serialization;

// Create a new WeatherForecast object
var weatherForecast = new WeatherForecast
{
    Date = DateTime.Parse("2021-12-01"),
    TemperatureCelsius = 7,
    Summary = "Overcast Clouds",
    Pressure = 1003,
    Humidity = 79,
    Coordinates = new Coordinates()
    {
        Lon = -83.9167,
        Lat = 9.8667
    },
    Wind = new Wind()
    {
        Speed = 11.32,
        Degree = 200,
        Gust = 17.49
    },
    SummaryWords = new[] { "Chill", "Windy" },
    WeatherCondition = WeatherCondition.Snow,
    WeatherLogo = "carvedrock.png",
    RequestTime = 42
};

// 1. Ignore individual properties
// Shows null values but ignores properties with [JsonIgnore]
var options = new JsonSerializerOptions
{
    WriteIndented = true   
};

string jsonString = JsonSerializer.Serialize(weatherForecast, options);
Console.WriteLine(jsonString);
Console.Clear();

// 2. Ignore read-only properties
options = new JsonSerializerOptions
{
    IgnoreReadOnlyProperties = true,
    WriteIndented = true
};
jsonString = JsonSerializer.Serialize(weatherForecast, options);
Console.WriteLine(jsonString);
Console.Clear();

// 3. Ignore null values
options = new JsonSerializerOptions
{
    WriteIndented = true,   
    DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
};

jsonString = JsonSerializer.Serialize(weatherForecast, options);
Console.WriteLine(jsonString);
Console.Clear();

// 4. Ignore default values
options = new()
{
    WriteIndented = true, 
    DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingDefault
};

jsonString = JsonSerializer.Serialize(weatherForecast, options);
Console.WriteLine(jsonString);
Console.Clear();

