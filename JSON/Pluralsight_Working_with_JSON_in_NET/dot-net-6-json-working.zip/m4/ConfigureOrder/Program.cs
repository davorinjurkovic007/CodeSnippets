﻿using System.Text.Json;
using System.Text.Json.Serialization;

// Create a new WeatherForecast object
var weatherForecast = new WeatherForecast
{
    Date = DateTime.Parse("2021-12-01"),
    TemperatureCelsius = 7,
    Summary = "Overcast Clouds",
    Pressure = 1003,
    Humidity = 79,
    Coordinates = new Coordinates()
    {
        Lon = -83.9167,
        Lat = 9.8667
    },
    Wind = new Wind()
    {
        Speed = 11.32,
        Degree = 200,
        Gust = 17.49
    },
    SummaryWords = new[] { "Chill", "Windy" },
    WeatherCondition = WeatherCondition.Snow
};

// No additional options specify order
var options = new JsonSerializerOptions
{
    WriteIndented = true,
};

// Serialize weatherForecast, order is determined via attributes
string jsonString = JsonSerializer.Serialize(weatherForecast, options);

File.WriteAllText("weather.json", jsonString);
Console.Clear();