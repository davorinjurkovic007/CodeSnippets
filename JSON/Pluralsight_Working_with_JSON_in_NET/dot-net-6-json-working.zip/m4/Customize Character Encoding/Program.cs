﻿using System.Text.Json;
using System.Text.Encodings.Web;
using System.Text.Unicode;

// Create a new WeatherForecast object, look at the word used in Summary
var weatherForecast = new WeatherForecast
{
    Date = DateTime.Parse("2021-12-01"),
    TemperatureCelsius = 7,
    Summary = "жарко"
};

string fileName = "WeatherForecast.json"; 

// 1. Serialize with no encoding options
// Replaces with \uxxxx where xxxx is the Unicode code of the character
var options = new JsonSerializerOptions { WriteIndented = true };
string jsonString = JsonSerializer.Serialize(weatherForecast, options);
File.WriteAllText(fileName, jsonString);

// 2. Serialize language character sets
// Notice usings at the top: System.Text.Encodings.Web and System.Text.Unicode
options = new JsonSerializerOptions
{
    Encoder = JavaScriptEncoder.Create(UnicodeRanges.BasicLatin, UnicodeRanges.Cyrillic),
    WriteIndented = true
};

jsonString = JsonSerializer.Serialize(weatherForecast, options);
File.WriteAllText(fileName, jsonString);

// 3. Serialize specific characters
// Possible to specify which characters can be or not be escaped
// This example serializes only the first two characters of жарко
var encoderSettings = new TextEncoderSettings();
encoderSettings.AllowCharacters('\u0436', '\u0430');
encoderSettings.AllowRange(UnicodeRanges.BasicLatin);
options = new JsonSerializerOptions
{
    Encoder = JavaScriptEncoder.Create(encoderSettings),
    WriteIndented = true
};

jsonString = JsonSerializer.Serialize(weatherForecast, options);
File.WriteAllText(fileName, jsonString);

// 4. Serialize all characters
// Possible to indicate to serialize all characters to minimize escaping
// Use with caution, only when sure that client will use UTF-8 encoding
options = new JsonSerializerOptions
{
    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    WriteIndented = true
};
jsonString = JsonSerializer.Serialize(weatherForecast, options);
File.WriteAllText(fileName, jsonString);
Console.Clear();

