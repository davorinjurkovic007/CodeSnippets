﻿using System.Text.Json;

// string variable that contains the JSON string
string jsonString = @"{
  ""date"":""2021-12-01T00:00:00-07:00"",
  ""temperaturecelsius"":7,
  ""feelslike"":3.14,
  ""description"":""overcast clouds"",
  ""pressure"":1003,
  ""humidity"":79,
  ""coord"": 
  {
    ""lon"":48.75,
    ""lat"":8.24
  },
  ""wind"":
  {
    ""speed"":11.32,
    ""deg"":200,
    ""gust"":17.49
  },
  ""keywords"":
  [
    ""Chill"",
    ""Windy""
  ],
  ""country"":""DE"",
  ""city"":""Baden-Baden""
}";

// 1. Deserialize with default options, namely case sensitive matching
// Deserialize JSON
WeatherForecast? weatherForecast = JsonSerializer.Deserialize<WeatherForecast>(jsonString);

// Check if object was deserialized
if (weatherForecast != null)
{
    // Print some deserialized properties
    Console.WriteLine($"Date: {weatherForecast.Date}");
    // Casing is different: "temperaturecelsius" in JSON vs. "TemperatureCelsius" in .NET
    Console.WriteLine($"TemperatureCelsius: {weatherForecast.TemperatureCelsius}");      
    Console.WriteLine($"Summary: {weatherForecast.Summary}");
}

// 2. Create a JsonSerializerOptions object with case-insensitive property names matching
var options = new JsonSerializerOptions
{
    PropertyNameCaseInsensitive = true
};

// Deserialize, passing the PropertyNameCaseInsensitive option
WeatherForecast? weatherForecastCaseInsensitive = JsonSerializer.Deserialize<WeatherForecast>(jsonString, options);

// Check if object was deserialized
if (weatherForecastCaseInsensitive != null)
{
    // Print some deserialized properties
    Console.WriteLine($"Date: {weatherForecastCaseInsensitive.Date}");
    Console.WriteLine($"TemperatureCelsius: {weatherForecastCaseInsensitive.TemperatureCelsius}");
    Console.WriteLine($"Summary: {weatherForecastCaseInsensitive.Summary}");
}