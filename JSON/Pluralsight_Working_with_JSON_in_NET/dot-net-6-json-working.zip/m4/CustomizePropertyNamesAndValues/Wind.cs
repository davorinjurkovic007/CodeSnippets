public class Wind
{
    public double Speed { get; set; }
    public int Degree { get; set; }
    public double Gust { get; set; }
}