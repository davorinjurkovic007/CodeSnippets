﻿using System.Text.Json;
using System.Text.Json.Serialization;

// JSON object with a description instead of Summary
string jsonString = @"{
  ""date"":""2021-12-01T00:00:00-07:00"",
  ""temperaturecelsius"":7,
  ""feelslike"":3.14,
  ""description"":""overcast clouds"",
  ""TemperatureRanges"": {
    ""ColdMinTemp"": 20,
    ""HotMinTemp"": 40
  }
}";

// Serialize weatherForecast 
WeatherForecast? weatherForecast = JsonSerializer.Deserialize<WeatherForecast>(jsonString);

// 1. Customize individual property names
// If nothing is printed out, go and uncomment [JsonPropertyName("description")] in the WeatherForecast class
if (weatherForecast != null)
{
  Console.WriteLine($"Description: {weatherForecast.Summary}");
}
Console.Clear();

// 2. Converting all property names to camelCase
// Without any additional options
JsonSerializerOptions optionsIndented = new JsonSerializerOptions
{
  WriteIndented = true
};

string weatherjson = JsonSerializer.Serialize(weatherForecast, optionsIndented);
Console.WriteLine(weatherjson);

// With PropertyNamingPolicy set to JsonNamingPolicy.CamelCase
JsonSerializerOptions optionsPropertyNamingPolicy = new JsonSerializerOptions
{
  PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
  WriteIndented = true
};

string weatherJson = JsonSerializer.Serialize(weatherForecast, optionsPropertyNamingPolicy);
Console.WriteLine(weatherJson);
Console.Clear();

// 3. Use a custom JSON property naming policy
// Created a policy (UpperCaseNamingPolicy.cs) to upper case properties
JsonSerializerOptions optionsCustomPolicy = new JsonSerializerOptions
{
    PropertyNamingPolicy = new UpperCaseNamingPolicy(),
    WriteIndented = true
};
string jsonCustomPolicy = JsonSerializer.Serialize(weatherForecast, optionsCustomPolicy);
Console.WriteLine(jsonCustomPolicy);
Console.Clear();

// 4. Converting dictionary keys to camel case
JsonSerializerOptions optionsDictKeyPolicyPolicy = new JsonSerializerOptions
{
    DictionaryKeyPolicy = JsonNamingPolicy.CamelCase,
    WriteIndented = true
};
string jsonDictKeyPolicy = JsonSerializer.Serialize(weatherForecast, optionsDictKeyPolicyPolicy);
Console.WriteLine(jsonDictKeyPolicy);
Console.Clear();

// 5. Enums as strings
var weatherWithEnums = new WeatherForecast
{
      Date = DateTime.Parse("2021-12-01"),
    TemperatureCelsius = 25,
    Summary = "Hot",
    FeelsLike = Feels.Hot
};

string jsonEnum = JsonSerializer.Serialize(weatherWithEnums, optionsIndented);
Console.WriteLine(jsonEnum);

var optionsEnums = new JsonSerializerOptions
{
    WriteIndented = true,
    Converters =
    {
        new JsonStringEnumConverter(JsonNamingPolicy.CamelCase)
    }
};

string jsonEnums = JsonSerializer.Serialize(weatherForecast, optionsEnums);
Console.WriteLine(jsonEnums);
Console.Clear();