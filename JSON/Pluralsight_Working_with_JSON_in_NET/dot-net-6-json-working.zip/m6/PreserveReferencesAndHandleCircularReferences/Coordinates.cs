public class Coordinates
    {
        public double Lon { get; set; }
        public double Lat { get; set; }
    }