﻿using System.Text.Json;
using System.Text.Json.Serialization;

WeatherForecast weatherForecast = new WeatherForecast
{
    Date = DateTime.Parse("2021-12-01"),
    TemperatureCelsius = -38,
    Summary = "Overcast Death",
};

WeatherForecast recordHot = new WeatherForecast
{
    Date = DateTime.Parse("2015-08-07"),
    TemperatureCelsius = 41,
    Summary = "Overcast Fire",
};

weatherForecast.Records = new List<WeatherForecast>();

// Add the hottest day ever
weatherForecast.Records.Add(recordHot);

// Add the coldest day ever 
weatherForecast.Records.Add(weatherForecast);

// 1. Preserve
var options = new JsonSerializerOptions
{
    WriteIndented = true,
    // To preserve references and handle circular references uncomment ReferenceHandler
    ReferenceHandler = ReferenceHandler.Preserve    
};

string jsonString = JsonSerializer.Serialize(weatherForecast, options);
Console.WriteLine(jsonString);
Console.Clear();

// 2. IgnoreCycles
options = new()
{    
    WriteIndented = true,
    ReferenceHandler = ReferenceHandler.IgnoreCycles
};

jsonString = JsonSerializer.Serialize(weatherForecast, options);
Console.WriteLine(jsonString);
Console.Clear();