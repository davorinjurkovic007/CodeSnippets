using System.Text.Json.Serialization;

public class Wind
    {
        public double Speed { get; set; }
        [JsonPropertyName("deg")]
        public int Degree { get; set; }
        public double Gust { get; set; }
    }