using System.Text.Json.Serialization;

public struct WeatherForecast
{
    public DateTime Date { get; }
    [JsonPropertyName("celsius")]
    public int TemperatureCelsius { get; }
    public string Summary { get; }
    // Uncomment to use this constructor
    [JsonConstructor]
    public WeatherForecast(DateTime date, int temperatureCelsius, string summary) =>
        (Date, TemperatureCelsius, Summary) = (date, temperatureCelsius, summary);
}