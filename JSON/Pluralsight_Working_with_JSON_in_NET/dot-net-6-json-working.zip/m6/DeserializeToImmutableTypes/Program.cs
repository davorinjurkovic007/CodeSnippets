﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;

string fileName = "forecast.json";
string jsonString = File.ReadAllText(fileName);

Console.WriteLine($"Input JSON:\r\n{jsonString}");
var options = new JsonSerializerOptions(JsonSerializerDefaults.Web);
var forecast = JsonSerializer.Deserialize<WeatherForecast>(jsonString, options);
Console.WriteLine();

Console.WriteLine($"forecast.Date: {forecast.Date}");
Console.WriteLine($"forecast.TemperatureCelsius: {forecast.TemperatureCelsius}");
Console.WriteLine($"forecast.Summary: {forecast.Summary}");
Console.WriteLine();

var roundTrippedJson =
    JsonSerializer.Serialize<WeatherForecast>(forecast, options);

Console.WriteLine($"Output JSON:\r\n{roundTrippedJson}");   
Console.Clear(); 
