﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;
    
string fileName = "forecast.json";
string jsonString = File.ReadAllText(fileName);
Console.WriteLine($"Input JSON:\r\n{jsonString}");

WeatherForecast forecastDeserialized = JsonSerializer.Deserialize<WeatherForecast>(jsonString);
Console.WriteLine($"Date: {forecastDeserialized.Date}");
Console.WriteLine($"TemperatureCelsius: {forecastDeserialized.TemperatureCelsius}");
// Summary is not accessible because of the private get accessor
// Console.WriteLine($"Summary: {forecastDeserialized.Summary}");

jsonString = JsonSerializer.Serialize<WeatherForecast>(forecastDeserialized);
Console.WriteLine($"Output JSON: {jsonString}");
Console.Clear();