using System.Text.Json.Serialization;

public class WeatherForecast
{
    public DateTime Date { get; init; }

    [JsonInclude]
    public int TemperatureCelsius { get; private set; }

    [JsonInclude]
    public string Summary { private get; set; }
};