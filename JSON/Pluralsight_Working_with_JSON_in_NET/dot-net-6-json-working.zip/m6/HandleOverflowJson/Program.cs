﻿using System.Text.Json;
using System.Text.Json.Serialization;

string fileName = "forecast.json";
string jsonString = File.ReadAllText(fileName);

// 1. Deserialize
WeatherForecast? weatherForecast = JsonSerializer.Deserialize<WeatherForecast>(jsonString);

if (weatherForecast != null)
{
    Console.WriteLine("- Expected properties:");
    Console.WriteLine($"Date: {weatherForecast.Date}");
    Console.WriteLine($"TemperatureCelsius: {weatherForecast.TemperatureCelsius}");
    Console.WriteLine($"Summary: {weatherForecast.Summary}");

    Console.WriteLine("- Extension data:");
    if (weatherForecast.ExtensionData != null)
    {
        foreach (var item in weatherForecast.ExtensionData)
        {
            Console.WriteLine($"{item.Key}: {item.Value}");
        }
    } 
}

Console.Clear();

// 2. Serialize
var options = new JsonSerializerOptions
{
    WriteIndented = true
};
string newJsonString = JsonSerializer.Serialize(weatherForecast, options);
Console.WriteLine(newJsonString);
Console.Clear();