﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;

var seismicForecast = new WeatherForecastSeismic() 
{
    Date = DateTime.Parse("2021-12-01"),
    TemperatureCelsius = 30,
    Summary = "Hot",
    TimeToNextEarthquake = DateTime.Parse("07:22:16"),
    MagnitudeOfNextEarthquake = 4.5
};

JsonSerializerOptions options = new JsonSerializerOptions
{
    WriteIndented = true
};
string jsonString = JsonSerializer.Serialize(seismicForecast, seismicForecast.GetType(), options);

Console.WriteLine(jsonString);
Console.Clear();

