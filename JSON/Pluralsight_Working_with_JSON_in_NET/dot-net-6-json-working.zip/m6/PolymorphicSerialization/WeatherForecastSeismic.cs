public class WeatherForecastSeismic : WeatherForecast
{
    public DateTime TimeToNextEarthquake { get; set; }
    public double MagnitudeOfNextEarthquake { get; set; }
};