﻿using System.Text.Json;
using System.Text.Json.Serialization;

// Uncomment lines to allow invalid JSON
var options = new JsonSerializerOptions
{
    ReadCommentHandling = JsonCommentHandling.Skip,
    AllowTrailingCommas = true,
    NumberHandling =  JsonNumberHandling.AllowReadingFromString | JsonNumberHandling.WriteAsString
};

string fileName = "Invalid.json";
string jsonString = File.ReadAllText(fileName);
WeatherForecast? weatherForecast = JsonSerializer.Deserialize<WeatherForecast>(jsonString, options);

if (weatherForecast != null)
{
    Console.WriteLine($"Date: {weatherForecast.Date}");
    Console.WriteLine($"TemperatureCelsius: {weatherForecast.TemperatureCelsius}");
    Console.WriteLine($"Summary: {weatherForecast.Summary}");
}

Console.Clear();