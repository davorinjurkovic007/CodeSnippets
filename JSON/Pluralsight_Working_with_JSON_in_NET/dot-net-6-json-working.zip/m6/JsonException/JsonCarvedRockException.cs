using System.Text.Json;

public class JsonCarvedRockException : JsonException 
{
     public JsonCarvedRockException()
    {
    }

    public JsonCarvedRockException(string message)
        : base(message)
    {
    }

    public JsonCarvedRockException(string message, Exception inner)
        : base(message, inner)
    {
    }
}