public class Product{
    public string? Name { get; set; }
    public DateTime ExpiryDate { get; set; }
}