﻿using System;
using System.Text.Json;

// 1. A JsonException is raised because the date is in an incorrect format
// A new exception is created and thrown
string fileName = "product.json";
string jsonString = File.ReadAllText(fileName);

try
{
    Product? product = JsonSerializer.Deserialize<Product>(jsonString);
}
catch (JsonException e)
{
    Console.WriteLine(e.Message);
    JsonCarvedRockException carvedRockException = new JsonCarvedRockException("Main failed to execute", e);
    throw carvedRockException;
}