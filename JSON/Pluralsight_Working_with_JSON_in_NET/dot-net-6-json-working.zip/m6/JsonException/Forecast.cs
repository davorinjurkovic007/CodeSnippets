public class Forecast
{
    public DateTime Date { get; set; }
    public int Data { get; set; }
    public string? Summary { get; set; }
}