﻿using System.Text.Json;
using System.Text.Json.Serialization;

string jsonString = @"{
""Date"": ""2019-08-01T00:00:00"",
""TemperatureCelsius"": 25,
""Summary"": ""Hot""
}";
WeatherForecast? weatherForecast;

// Deserialize with context that selects metadata mode only for WeatherForecast only.
weatherForecast = JsonSerializer.Deserialize<WeatherForecast>(
    jsonString, MetadataOnlyWeatherForecastOnlyContext.Default.WeatherForecast);
Console.WriteLine($"Date={weatherForecast?.Date}");

// Serialize with context that selects metadata mode only for WeatherForecast only.
jsonString = JsonSerializer.Serialize(
    weatherForecast!,
    MetadataOnlyWeatherForecastOnlyContext.Default.WeatherForecast);
Console.WriteLine(jsonString);


// Deserialize with context that selects metadata mode only.
weatherForecast = JsonSerializer.Deserialize<WeatherForecast>(
    jsonString, MetadataOnlyContext.Default.WeatherForecast);
Console.WriteLine($"Date={weatherForecast?.Date}");
// output:
//Date=8/1/2019 12:00:00 AM

// Serialize with context that selects metadata mode only.
jsonString = JsonSerializer.Serialize(
    weatherForecast!, MetadataOnlyContext.Default.WeatherForecast);
Console.WriteLine(jsonString);
Console.Clear();