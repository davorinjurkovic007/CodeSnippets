﻿using System.Text.Json;
using System.Collections;

Dictionary<Feels, String> currentWeather = new Dictionary<Feels, string>();

currentWeather.Add(Feels.Cold, "I am from Costa Rica, this guy is freezing!");
currentWeather.Add(Feels.Cool, "I am from Vermont, this is OK");
currentWeather.Add(Feels.Warm, "I am from Canada, this is what we call a Tuesday");
currentWeather.Add(Feels.Hot, "I am from Siberia, this feels like summer");

string jsonFeels = JsonSerializer.Serialize(currentWeather);
Console.WriteLine(jsonFeels);
Console.WriteLine();

JsonSerializerOptions optionsTKEVA = new JsonSerializerOptions
{
    WriteIndented = true,
    Converters =
    {
        new DictionaryTKeyEnumTValueConverter()
    }
};

jsonFeels = JsonSerializer.Serialize(currentWeather, optionsTKEVA);
Console.WriteLine(jsonFeels);
Console.Clear();
