public enum Feels
{
    Cold, Cool, Warm, Hot
}