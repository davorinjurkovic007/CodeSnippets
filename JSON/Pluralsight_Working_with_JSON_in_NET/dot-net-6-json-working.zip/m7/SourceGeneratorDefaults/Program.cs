﻿using System.Text.Json;

string jsonString = @"{
    ""Date"": ""2019-08-01T00:00:00"",
    ""TemperatureCelsius"": 25,
    ""Summary"": ""Hot""
}";

WeatherForecast? weatherForecast;

weatherForecast = JsonSerializer.Deserialize<WeatherForecast>(jsonString,
    SourceGenerationContext.Default.WeatherForecast);
Console.WriteLine($"Date={weatherForecast?.Date}");


weatherForecast = JsonSerializer.Deserialize(jsonString, typeof(WeatherForecast),
    SourceGenerationContext.Default) as WeatherForecast;
Console.WriteLine($"Date={weatherForecast?.Date}");


jsonString = JsonSerializer.Serialize(weatherForecast!,
    SourceGenerationContext.Default.WeatherForecast);
Console.WriteLine(jsonString);

jsonString = JsonSerializer.Serialize(weatherForecast, typeof(WeatherForecast),
    SourceGenerationContext.Default);
Console.WriteLine(jsonString);
Console.Clear();