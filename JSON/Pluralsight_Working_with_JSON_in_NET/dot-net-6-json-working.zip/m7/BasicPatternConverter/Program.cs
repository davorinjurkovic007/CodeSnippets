﻿using System.Text.Json;
string jsonString;

var weatherForecast = new WeatherForecast
{
    Date = DateTime.Parse("2021-12-01"),
    TemperatureCelsius = 25,
    Summary = "Hot"
};

Console.WriteLine("Without custom converter");
jsonString = JsonSerializer.Serialize(weatherForecast, new JsonSerializerOptions{WriteIndented = true});
Console.WriteLine(jsonString);
Console.WriteLine();

var serializeOptions = new JsonSerializerOptions
{
    WriteIndented = true,
    // Converters =
    // {
    //     new DateTimeOffsetJsonConverter()
    // }
};

Console.WriteLine("With DateTimeOffsetJsonConverter custom converter");
jsonString = JsonSerializer.Serialize(weatherForecast, serializeOptions);
Console.WriteLine(jsonString);
Console.WriteLine();