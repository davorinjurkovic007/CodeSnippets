﻿using System.Text.Json;
using System.Text.Json.Serialization;

string jsonString;

WeatherForecast weatherForecast = new()
    { Date = DateTime.Parse("2019-08-01"), TemperatureCelsius = 25, Summary = "Hot" };

// Use context that selects Serialization mode only for WeatherForecast.
jsonString = JsonSerializer.Serialize(weatherForecast, SerializeOnlyWeatherForecastOnlyContext.Default.WeatherForecast);
Console.WriteLine(jsonString);

// Use a context that selects Serialization mode.
jsonString = JsonSerializer.Serialize(weatherForecast,  SerializeOnlyContext.Default.WeatherForecast);
Console.WriteLine(jsonString);
Console.Clear();